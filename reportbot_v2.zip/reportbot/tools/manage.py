"""Admin helper (run inside the container):

  python -m tools.manage init                                   create tables + first admin
  python -m tools.manage add-user "Ramesh Patel" manager [telegram_id] [username password]
  python -m tools.manage set-login 3 ramesh StrongPass123      give / reset web username + password
  python -m tools.manage users                                  list users
  python -m tools.manage disable 3      |  enable 3             block / unblock a user (logs them out)
  python -m tools.manage logout-all 3                           sign a user out on every device
  python -m tools.manage seed-skills                            load examples/skills/*.json
  python -m tools.manage set-webhook                            register Telegram webhook
  python -m tools.manage run-schedule 3                         run a schedule now
"""
import json
import sys
from pathlib import Path

from app import config, store


def _web_hint(u: dict) -> str:
    if config.WEB_REQUIRE_PASSWORD:
        if u.get("username"):
            return f"Web login: {config.PUBLIC_BASE_URL}/  (username: {u['username']})"
        return (f"Web login not set yet. Run:  python -m tools.manage set-login {u['id']} "
                f"<username> <password>")
    return f"Web link: {config.PUBLIC_BASE_URL}/?token={u['web_token']}"


def main(argv):
    if not argv:
        print(__doc__)
        return
    cmd, args = argv[0], argv[1:]
    store.init_db()
    try:
        if cmd == "init":
            for u in store.list_users():
                print(f"#{u['id']} {u['name']} ({u['role']})  {_web_hint(u)}")
        elif cmd == "add-user":
            name, role = args[0], args[1]
            tg = args[2] if len(args) > 2 and args[2].isdigit() else None
            rest = args[3:] if tg else args[2:]
            u = store.add_user(name, role, tg)
            if len(rest) >= 2:
                store.set_login(u["id"], rest[0], rest[1])
                u = store.get_user(u["id"])
            print(f"Added #{u['id']} {u['name']} as {u['role']}\n{_web_hint(u)}")
        elif cmd == "set-login":
            uid, username, password = int(args[0]), args[1], args[2]
            store.set_login(uid, username, password)
            u = store.get_user(uid)
            print(f"Login set for #{uid} {u['name']}\n{_web_hint(u)}\n"
                  f"Send the password to {u['name']} privately; they can change it after logging in.")
        elif cmd == "users":
            print(f"{'id':<4} {'name':<22} {'role':<8} {'username':<16} {'telegram':<12} active")
            for u in store.list_users():
                print(f"{u['id']:<4} {u['name'][:22]:<22} {u['role']:<8} {(u.get('username') or '-'):<16} "
                      f"{(u['telegram_id'] or '-'):<12} {bool(u['active'])}")
        elif cmd in ("disable", "enable"):
            uid = int(args[0])
            if uid == 1 and cmd == "disable":
                print("Refusing to disable the main admin (id 1).")
                return
            store.set_active(uid, cmd == "enable")
            print(f"User #{uid} {'enabled' if cmd == 'enable' else 'disabled and logged out'}.")
        elif cmd == "logout-all":
            store.end_all_sessions(int(args[0]))
            print(f"User #{args[0]} signed out everywhere.")
        elif cmd == "seed-skills":
            folder = Path(args[0]) if args else Path(__file__).resolve().parent.parent / "examples/skills"
            for f in sorted(folder.glob("*.json")):
                s = store.save_skill(json.loads(f.read_text(encoding="utf-8")), changed_by="seed")
                print(f"/{s['name']} v{s['version']}")
        elif cmd == "set-webhook":
            from app import telegram
            print(telegram.set_webhook())
            telegram.set_commands()
        elif cmd == "run-schedule":
            from app import scheduler
            scheduler.reload()
            print(scheduler.run_schedule(int(args[0])))
        else:
            print(__doc__)
    except (ValueError, IndexError) as e:
        print(f"Error: {e}\n\n{__doc__}")


if __name__ == "__main__":
    main(sys.argv[1:])

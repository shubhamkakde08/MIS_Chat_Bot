"""Central settings, read from environment / .env file."""
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", BASE_DIR / "output"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def _get(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


ANTHROPIC_API_KEY = _get("ANTHROPIC_API_KEY")
CLAUDE_MODEL = _get("CLAUDE_MODEL", "claude-sonnet-5-5")

DATA_DB_URL = _get("DATA_DB_URL", "sqlite:///sample_data.db")
BOT_DB_URL = _get("BOT_DB_URL", "sqlite:///reportbot.db")

TELEGRAM_BOT_TOKEN = _get("TELEGRAM_BOT_TOKEN")
TELEGRAM_MODE = _get("TELEGRAM_MODE", "direct")  # direct | n8n
TELEGRAM_WEBHOOK_SECRET = _get("TELEGRAM_WEBHOOK_SECRET")

PUBLIC_BASE_URL = _get("PUBLIC_BASE_URL", "http://localhost:8000").rstrip("/")
SERVICE_API_KEY = _get("SERVICE_API_KEY")

BOOTSTRAP_ADMIN_NAME = _get("BOOTSTRAP_ADMIN_NAME", "admin")
BOOTSTRAP_ADMIN_TELEGRAM_ID = _get("BOOTSTRAP_ADMIN_TELEGRAM_ID")
BOOTSTRAP_ADMIN_WEB_TOKEN = _get("BOOTSTRAP_ADMIN_WEB_TOKEN")

MAX_ROWS = int(_get("MAX_ROWS", "5000"))
QUERY_TIMEOUT_SECONDS = int(_get("QUERY_TIMEOUT_SECONDS", "30"))
TIMEZONE = _get("TIMEZONE", "Asia/Kolkata")
COMPANY_NAME = _get("COMPANY_NAME", "Your Company")

# Web login. True = username + password required; personal ?token= links stop working.
WEB_REQUIRE_PASSWORD = _get("WEB_REQUIRE_PASSWORD", "true").lower() in ("1", "true", "yes")
SESSION_HOURS = int(_get("SESSION_HOURS", "12"))
LOGIN_MAX_FAILS = int(_get("LOGIN_MAX_FAILS", "5"))
LOGIN_LOCK_MINUTES = int(_get("LOGIN_LOCK_MINUTES", "15"))

# How many previous chat turns the agent remembers per chat
CHAT_MEMORY_TURNS = int(_get("CHAT_MEMORY_TURNS", "12"))
# Max tool-use rounds per request (safety stop)
MAX_AGENT_STEPS = int(_get("MAX_AGENT_STEPS", "12"))

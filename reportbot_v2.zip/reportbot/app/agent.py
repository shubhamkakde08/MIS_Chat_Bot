"""The Claude agent: understands Hindi / English / Gujarati / Marathi, explores the
MySQL schema, runs safe SELECTs, learns report "skills" and produces reports.

One entry point:  handle_message(user, text, channel, chat_key) -> AgentReply
"""
from __future__ import annotations

import json
import re
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from zoneinfo import ZoneInfo

import anthropic

from . import config, datadb, renderers, store

client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY or "missing")


@dataclass
class AgentReply:
    text: str
    tables: list[str] = field(default_factory=list)   # monospace chat tables
    files: list[dict] = field(default_factory=list)   # rendered report files
    report_ids: list[int] = field(default_factory=list)
    preview: list[dict] = field(default_factory=list)  # {"columns","rows"} for web UI


@dataclass
class Ctx:
    user: dict
    role: dict
    channel: str
    chat_key: str
    request_text: str
    active_skill: dict | None = None
    results: dict = field(default_factory=dict)
    reply: AgentReply = field(default_factory=lambda: AgentReply(text=""))
    default_chat_id: str = ""


# =================================================================== tools
TOOLS = [
    {"name": "list_tables",
     "description": "List database tables/views the user may read. Use `search` to filter by "
                    "part of a name (e.g. 'sale', 'invoice', 'item'). Call this before writing SQL "
                    "if you don't know the schema.",
     "input_schema": {"type": "object", "properties": {
         "search": {"type": "string", "description": "optional substring"}}}},
    {"name": "describe_tables",
     "description": "Get columns, types, comments and foreign keys for up to 15 tables.",
     "input_schema": {"type": "object", "properties": {
         "tables": {"type": "array", "items": {"type": "string"}}}, "required": ["tables"]}},
    {"name": "run_sql",
     "description": "Run ONE read-only MySQL SELECT. Returns a result_id, the columns and a preview "
                    "of up to 30 rows. Shape the SQL like the final report (column order, aliases "
                    "as readable headers, grouping, sorting). Use the result_id with create_report.",
     "input_schema": {"type": "object", "properties": {
         "sql": {"type": "string"},
         "purpose": {"type": "string", "description": "one line: what this query answers"}},
         "required": ["sql"]}},
    {"name": "list_report_skills",
     "description": "List taught report skills (each one is a /command) the user may run.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "get_report_skill",
     "description": "Load a report skill's full definition: rules, format, reference SQL, example.",
     "input_schema": {"type": "object", "properties": {"name": {"type": "string"}},
                      "required": ["name"]}},
    {"name": "save_report_skill",
     "description": "Create or update a report skill (teaching). ONLY call after you showed the user "
                    "the draft definition and a test preview, and they confirmed. Updating an "
                    "existing name creates a new version (old versions are kept).",
     "input_schema": {"type": "object", "properties": {
         "name": {"type": "string", "description": "lowercase_with_underscores, becomes /name"},
         "title": {"type": "string"},
         "description": {"type": "string", "description": "what the report is for, who reads it"},
         "rules": {"type": "string", "description": "business rules & regulations, as a numbered list"},
         "output_format": {"type": "string", "description": "columns in order, headers, grouping, "
                           "sorting, totals, number formats, chart, summary style, language"},
         "default_formats": {"type": "array", "items": {"enum": list(renderers.ALL_FORMATS)}},
         "sql_template": {"type": "string", "description": "tested reference SQL; mark variable "
                          "parts like {from_date} {to_date} {branch} in comments"},
         "example_output": {"type": "string", "description": "sample of the desired report"},
         "allowed_roles": {"type": "array", "items": {"type": "string"},
                           "description": "empty = everyone"}},
         "required": ["name", "title", "rules", "output_format"]}},
    {"name": "create_report",
     "description": "Render a query result as the final report in one or more formats: "
                    "table (shown in chat), excel, pdf, chart (PNG), html. Saves it to history.",
     "input_schema": {"type": "object", "properties": {
         "result_id": {"type": "string"},
         "title": {"type": "string"},
         "subtitle": {"type": "string", "description": "e.g. period / branch / filters"},
         "summary": {"type": "string", "description": "3-6 line insight summary IN THE USER'S "
                     "LANGUAGE: totals, top items, changes, anything unusual"},
         "notes": {"type": "string"},
         "formats": {"type": "array", "items": {"enum": list(renderers.ALL_FORMATS)}},
         "column_labels": {"type": "object", "description": "optional rename {old: new}"},
         "column_formats": {"type": "object", "description": "{column: number|currency|percent|date|text}"},
         "total_columns": {"type": "array", "items": {"type": "string"}},
         "chart": {"type": "object", "properties": {
             "type": {"enum": ["bar", "barh", "line", "pie"]}, "x": {"type": "string"},
             "y": {"type": "array", "items": {"type": "string"}},
             "title": {"type": "string", "description": "English only (charts can't draw Indic scripts)"}}},
         "skill_name": {"type": "string"}},
         "required": ["result_id", "title", "formats"]}},
    {"name": "search_report_history",
     "description": "Find previously generated reports (newest first).",
     "input_schema": {"type": "object", "properties": {
         "query": {"type": "string"}, "skill_name": {"type": "string"},
         "limit": {"type": "integer", "default": 10}}}},
    {"name": "get_past_report",
     "description": "Open one past report: its SQL, summary, files and first rows. Use to compare "
                    "with last time or to re-create it in another format (re-run its SQL).",
     "input_schema": {"type": "object", "properties": {"report_id": {"type": "integer"}},
                      "required": ["report_id"]}},
    {"name": "create_schedule",
     "description": "Schedule a report skill to be sent automatically to a Telegram chat. "
                    "Confirm the time with the user first. Cron is in local time "
                    f"({config.TIMEZONE}), 5 fields: minute hour day month weekday.",
     "input_schema": {"type": "object", "properties": {
         "skill_name": {"type": "string"},
         "cron": {"type": "string", "description": "e.g. '0 9 * * 1-6' = 9:00 AM Mon-Sat"},
         "prompt": {"type": "string", "description": "extra instruction, e.g. 'for yesterday'"},
         "formats": {"type": "array", "items": {"enum": list(renderers.ALL_FORMATS)}},
         "target_chat_id": {"type": "string", "description": "Telegram chat/group id; "
                            "omit to use the current chat"},
         "name": {"type": "string"}},
         "required": ["skill_name", "cron"]}},
    {"name": "list_schedules", "description": "List active scheduled reports.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "cancel_schedule", "description": "Stop a scheduled report by id.",
     "input_schema": {"type": "object", "properties": {"schedule_id": {"type": "integer"}},
                      "required": ["schedule_id"]}},
]


def _tool_list_tables(ctx: Ctx, search: str = ""):
    names = datadb.list_tables(ctx.role["allowed_tables"], search)
    return {"count": len(names), "tables": names[:300],
            **({"note": "more tables exist, use search"} if len(names) > 300 else {})}


def _tool_describe_tables(ctx: Ctx, tables: list[str]):
    return datadb.describe_tables(tables, ctx.role["allowed_tables"])


def _tool_run_sql(ctx: Ctx, sql: str, purpose: str = ""):
    if not ctx.role.get("free_query") and not ctx.active_skill:
        return {"error": "Your role can only run taught reports. Ask the user which /report "
                         "they want (list_report_skills), then load it with get_report_skill."}
    try:
        res = datadb.run_select(sql, ctx.role["allowed_tables"])
    except datadb.SQLRejected as e:
        return {"error": f"Rejected: {e}"}
    except Exception as e:  # DB error -> let Claude fix its SQL
        return {"error": f"Database error: {str(e)[:600]}"}
    rid = f"r{len(ctx.results) + 1}"
    ctx.results[rid] = res
    return {"result_id": rid, "columns": res["columns"], "row_count": res["row_count"],
            "truncated": res["truncated"], "seconds": res["seconds"],
            "preview_rows": res["rows"][:30]}


def _skill_brief(s: dict) -> dict:
    return {"name": s["name"], "command": "/" + s["name"], "title": s["title"],
            "description": (s.get("description") or "")[:200],
            "default_formats": s.get("default_formats"), "version": s.get("version")}


def _tool_list_report_skills(ctx: Ctx):
    return [_skill_brief(s) for s in store.list_skills(ctx.user)]


def _tool_get_report_skill(ctx: Ctx, name: str):
    s = store.get_skill(name)
    if not s:
        return {"error": f"No skill named {name}"}
    if not store.skill_allowed(s, ctx.user):
        return {"error": "This report is not available for your role."}
    ctx.active_skill = s
    return {k: (v.isoformat() if isinstance(v, datetime) else v) for k, v in s.items()}


def _tool_save_report_skill(ctx: Ctx, **kw):
    if not ctx.role.get("can_teach"):
        return {"error": "Your role is not allowed to teach/change reports."}
    try:
        s = store.save_skill(kw, changed_by=ctx.user["name"])
    except ValueError as e:
        return {"error": str(e)}
    if config.TELEGRAM_BOT_TOKEN:  # show the new /command in Telegram's menu
        try:
            from . import telegram
            telegram.set_commands()
        except Exception:
            pass
    return {"saved": True, "command": "/" + s["name"], "version": s["version"]}


def _tool_create_report(ctx: Ctx, result_id: str, title: str, formats: list[str], **kw):
    res = ctx.results.get(result_id)
    if not res:
        return {"error": f"Unknown result_id {result_id}. Run run_sql first."}
    labels = kw.get("column_labels") or {}
    columns = [labels.get(c, c) for c in res["columns"]]
    remap = lambda d: {labels.get(k, k): v for k, v in (d or {}).items()}
    spec = renderers.ReportSpec(
        title=title, columns=columns, rows=res["rows"], subtitle=kw.get("subtitle", ""),
        summary=kw.get("summary", ""), notes=kw.get("notes", ""),
        column_formats=remap(kw.get("column_formats")),
        total_columns=[labels.get(c, c) for c in (kw.get("total_columns") or [])],
        chart=({**kw["chart"], "x": labels.get(kw["chart"].get("x"), kw["chart"].get("x")),
                "y": [labels.get(y, y) for y in kw["chart"].get("y") or []]}
               if kw.get("chart") else None),
        skill_name=store.normalize_skill_name(kw.get("skill_name") or
                                              (ctx.active_skill or {}).get("name", "")),
    )
    if res["truncated"]:
        spec.notes = (spec.notes + "\n" if spec.notes else "") + \
            f"Note: limited to the first {config.MAX_ROWS} rows."
    out = renderers.render(spec, formats)
    report_id = store.save_report(
        user_id=ctx.user["id"], channel=ctx.channel, skill_name=spec.skill_name, title=title,
        request_text=ctx.request_text[:4000], sql_text=res["sql"], row_count=res["row_count"],
        summary=spec.summary, data_preview=[columns] + res["rows"][:50],
        files=[{k: f[k] for k in ("format", "filename", "url", "path")} for f in out["files"]])
    if out["table_text"]:
        ctx.reply.tables.append(f"{title}\n\n{out['table_text']}")
        ctx.reply.preview.append({"title": title, "columns": columns, "rows": res["rows"][:200]})
    ctx.reply.files.extend(out["files"])
    ctx.reply.report_ids.append(report_id)
    return {"report_id": report_id, "formats_created": [f["format"] for f in out["files"]] +
            (["table"] if out["table_text"] else []),
            "note": "Files are delivered to the user automatically. Do not paste links or the "
                    "full table again; just give the summary in the user's language."}


def _tool_search_report_history(ctx: Ctx, query: str = "", skill_name: str = "", limit: int = 10):
    rows = store.search_reports(ctx.user, query, skill_name, min(limit, 30))
    return [{"report_id": r["id"], "title": r["title"], "skill": r["skill_name"],
             "rows": r["row_count"], "created_at": str(r["created_at"]),
             "formats": [f["format"] for f in r["files"] or []],
             "request": (r["request_text"] or "")[:150]} for r in rows]


def _tool_get_past_report(ctx: Ctx, report_id: int):
    r = store.get_report(report_id)
    if not r or (r["user_id"] != ctx.user["id"] and not ctx.role.get("is_admin")):
        return {"error": "Report not found"}
    return {"report_id": r["id"], "title": r["title"], "skill": r["skill_name"],
            "created_at": str(r["created_at"]), "sql": r["sql_text"], "summary": r["summary"],
            "row_count": r["row_count"], "first_rows": (r["data_preview"] or [])[:31],
            "files": [{"format": f["format"], "url": f["url"]} for f in r["files"] or []]}


def _tool_create_schedule(ctx: Ctx, skill_name: str, cron: str, prompt: str = "",
                          formats: list[str] | None = None, target_chat_id: str = "", name: str = ""):
    if not ctx.role.get("can_schedule"):
        return {"error": "Your role is not allowed to create schedules."}
    s = store.get_skill(skill_name)
    if not s:
        return {"error": f"No skill named {skill_name}"}
    chat_id = target_chat_id or ctx.default_chat_id or ctx.user.get("telegram_id") or ""
    if not chat_id:
        return {"error": "No Telegram chat id. Ask the user to /start the Telegram bot first, "
                         "or give a group chat id."}
    from . import scheduler  # late import to avoid cycle
    try:
        scheduler.validate_cron(cron)
    except ValueError as e:
        return {"error": str(e)}
    sch = store.add_schedule(name=name or f"{s['title']} ({cron})", skill_name=s["name"],
                             cron=cron, prompt=prompt,
                             formats=",".join(formats or (s["default_formats"] or "excel").split(",")),
                             target_chat_id=str(chat_id), owner_user_id=ctx.user["id"])
    scheduler.reload()
    return {"schedule_id": sch["id"], "next_run": scheduler.next_run(sch["id"])}


def _tool_list_schedules(ctx: Ctx):
    from . import scheduler
    return [{"id": s["id"], "name": s["name"], "skill": s["skill_name"], "cron": s["cron"],
             "formats": s["formats"], "chat": s["target_chat_id"],
             "next_run": scheduler.next_run(s["id"])} for s in store.list_schedules(ctx.user)]


def _tool_cancel_schedule(ctx: Ctx, schedule_id: int):
    mine = {s["id"] for s in store.list_schedules(ctx.user)}
    if schedule_id not in mine:
        return {"error": "Schedule not found"}
    store.set_schedule_active(schedule_id, False)
    from . import scheduler
    scheduler.reload()
    return {"cancelled": schedule_id}


DISPATCH = {t["name"]: globals()[f"_tool_{t['name']}"] for t in TOOLS}


# =================================================================== prompt
def _system_prompt(ctx: Ctx) -> list[dict]:
    now = datetime.now(ZoneInfo(config.TIMEZONE))
    fy_start = now.year if now.month >= 4 else now.year - 1
    skills_txt = "\n".join(f"- /{s['name']}: {s['title']}" for s in store.list_skills(ctx.user)) \
        or "(none yet - offer to teach the first one)"
    static = f"""You are ReportBot, the reporting assistant of {config.COMPANY_NAME}. You turn plain-language requests into accurate reports from the company's MySQL database.

## Language
- Users write in English, Hindi, Gujarati or Marathi, in native script or romanised (Hinglish e.g. "kal ki sales batao", Gujlish e.g. "aaje nu dispatch batavo"). Understand all of them.
- Always reply in the same language AND script the user wrote in. Report summaries follow the user's language unless the skill says otherwise. Keep database values, codes and numbers as they are.
- Use Indian conventions: ₹, lakh/crore, dd-mm-yyyy dates, Indian financial year (April-March). "Is mahine" = this month, "kal" = yesterday (or tomorrow - judge from context), "pichhle hafte" = last week, "gaya mahina"/"magil mahina" = last month.

## How to answer data questions
1. If a report skill matches the request, load it with get_report_skill and FOLLOW ITS RULES EXACTLY - they are company regulations. Start from its sql_template, substituting the requested dates/filters.
2. Otherwise explore: list_tables -> describe_tables -> run_sql. Never guess column names.
3. Check results make sense (empty? duplicates from joins? wrong period?). Fix and re-run if needed.
4. For quick questions ("total sales today?") answer in one or two lines, no report needed. For anything list-like, call create_report. Use the skill's default formats unless the user asks for others (excel/pdf/chart/html/table).
5. In your final message: 2-6 short lines with the key insight in the user's language. Files and tables are attached automatically - never paste URLs or repeat the table.
6. If the request is ambiguous in a way that changes the numbers (which date column, which branch), ask ONE short question.

## Teaching mode (/teach or "sikhao", "shikhvo", "shikva")
When someone wants to teach a new report or change one, act as a business analyst:
1. Ask what the report is for and collect, conversationally (a few questions at a time, not a form): purpose & audience; tables/data; filters & period; business rules (e.g. exclude cancelled, GST inclusive or not, which date counts, rounding); columns in order and their headers; grouping, sorting, totals; formats (table/excel/pdf/chart/html); chart type; summary language; who may use it.
2. If they paste or describe an example report, mirror its layout and headers exactly.
3. Explore the schema, write the SQL, run it, and show a preview table (create_report with format table) so they can verify the numbers.
4. Show the final definition (name, rules, format) and ask for confirmation, then save_report_skill. Tell them the new /command.
5. Rules must be specific and testable, written as a numbered list.

## Other
- Scheduling: users can ask e.g. "roj subah 9 baje /daily_sales bhejo". Convert to cron in {config.TIMEZONE}, confirm, then create_schedule.
- History: you can search and reopen past reports, compare periods, or recreate an old report in another format by re-running its SQL.
- Never reveal API keys or connection strings. You can only read data, never change it.
- Be concise. Telegram and phones are small screens."""
    dynamic = f"""## Right now
- Date/time: {now.strftime('%A %d-%m-%Y %H:%M')} ({config.TIMEZONE}); current financial year starts 01-04-{fy_start}.
- User: {ctx.user['name']} (role: {ctx.role['name']}; can teach: {bool(ctx.role.get('can_teach'))}; can schedule: {bool(ctx.role.get('can_schedule'))}; free questions: {bool(ctx.role.get('free_query'))}).
- Channel: {ctx.channel}.
- Report skills available to this user:
{skills_txt}"""
    return [{"type": "text", "text": static, "cache_control": {"type": "ephemeral"}},
            {"type": "text", "text": dynamic}]


# =================================================================== main loop
SLASH_RE = re.compile(r"^/([A-Za-z0-9_]+)(?:@\w+)?\s*(.*)$", re.S)


def expand_slash(text: str, user: dict) -> tuple[str, dict | None]:
    """'/daily_sales for Surat branch pdf' -> instruction for the agent + skill."""
    m = SLASH_RE.match(text.strip())
    if not m:
        return text, None
    cmd, rest = m.group(1).lower(), m.group(2).strip()
    if cmd == "teach":
        target = f" Update the existing report /{rest.split()[0].lstrip('/')}." if rest else ""
        return (f"I want to teach you a new report (or change one).{target} "
                f"Start the teaching interview. {rest}").strip(), None
    s = store.get_skill(cmd)
    if not s:
        return text, None
    if not store.skill_allowed(s, user):
        return f"(User tried /{cmd} but their role is not allowed. Tell them politely.)", None
    instr = f"Run report skill /{s['name']}."
    instr += f" User's extra input: {rest}" if rest else " Use default period/filters from its rules."
    return instr, s


def handle_message(user: dict, text: str, channel: str, chat_key: str,
                   default_chat_id: str = "", remember: bool = True) -> AgentReply:
    role = store.get_role(user["role"])
    prompt, skill = expand_slash(text, user)
    ctx = Ctx(user=user, role=role, channel=channel, chat_key=chat_key, request_text=text,
              active_skill=skill, default_chat_id=default_chat_id)
    if skill:
        prompt += "\n\n<skill_definition>\n" + json.dumps(
            _tool_get_report_skill(ctx, skill["name"]), ensure_ascii=False, default=str) + \
            "\n</skill_definition>"

    history = store.recent_messages(chat_key, config.CHAT_MEMORY_TURNS) if remember else []
    msgs = history + [{"role": "user", "content": prompt}]
    system = _system_prompt(ctx)

    final_text = ""
    try:
        for _ in range(config.MAX_AGENT_STEPS):
            resp = client.messages.create(
                model=config.CLAUDE_MODEL, max_tokens=4096, system=system,
                tools=TOOLS, messages=msgs)
            msgs.append({"role": "assistant", "content": resp.content})
            texts = [b.text for b in resp.content if b.type == "text"]
            if resp.stop_reason != "tool_use":
                final_text = "\n".join(texts).strip()
                break
            results = []
            for b in resp.content:
                if b.type != "tool_use":
                    continue
                try:
                    out = DISPATCH[b.name](ctx, **(b.input or {}))
                except Exception as e:
                    traceback.print_exc()
                    out = {"error": f"{type(e).__name__}: {e}"}
                results.append({"type": "tool_result", "tool_use_id": b.id,
                                "content": json.dumps(out, ensure_ascii=False, default=str)[:60000],
                                **({"is_error": True} if isinstance(out, dict) and "error" in out else {})})
            msgs.append({"role": "user", "content": results})
        else:
            final_text = "I had to stop because this took too many steps. Please narrow the request."
    except anthropic.APIError as e:
        final_text = f"⚠️ AI service error: {getattr(e, 'message', str(e))[:300]}"

    ctx.reply.text = final_text or ("✅ Done." if ctx.reply.files or ctx.reply.tables else "…")
    if remember:
        store.add_message(chat_key, "user", text)
        memo = ctx.reply.text
        if ctx.reply.report_ids:
            memo += f"\n[Created report id(s) {ctx.reply.report_ids}: " + \
                    ", ".join(sorted({f['format'] for f in ctx.reply.files} |
                                     ({"table"} if ctx.reply.tables else set()))) + "]"
        store.add_message(chat_key, "assistant", memo)
    return ctx.reply

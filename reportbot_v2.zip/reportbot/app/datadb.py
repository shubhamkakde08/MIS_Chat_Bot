"""Access to YOUR business MySQL database — strictly read-only.

Three layers of protection:
  1. Connect with a MySQL user that only has SELECT grants (see .env.example).
  2. Every query is parsed with sqlglot: one statement, SELECT only, no
     INTO OUTFILE / LOAD_FILE / SLEEP etc., and only tables the user's role allows.
  3. The session is set READ ONLY with a max execution time.
"""
from __future__ import annotations

import datetime as dt
import decimal
import time
from functools import lru_cache

import sqlglot
from sqlalchemy import create_engine, inspect, text
from sqlglot import exp

from . import config

engine = create_engine(config.DATA_DB_URL, pool_pre_ping=True, pool_recycle=1800, future=True)
DIALECT = "mysql" if engine.dialect.name in ("mysql", "mariadb") else engine.dialect.name

BLOCKED_FUNCTIONS = {"load_file", "sleep", "benchmark", "get_lock", "release_lock",
                     "sys_exec", "sys_eval", "pg_sleep"}
BLOCKED_NODES = (exp.Insert, exp.Update, exp.Delete, exp.Drop, exp.Create, exp.Alter,
                 exp.Command, exp.Merge, exp.TruncateTable, exp.Grant, exp.Into)


class SQLRejected(Exception):
    pass


# ------------------------------------------------------------------ schema
@lru_cache(maxsize=1)
def _all_tables() -> tuple[str, ...]:
    insp = inspect(engine)
    return tuple(sorted(insp.get_table_names() + insp.get_view_names()))


def refresh_schema_cache() -> None:
    _all_tables.cache_clear()
    _describe.cache_clear()


def _visible(allowed: list[str]) -> list[str]:
    tables = list(_all_tables())
    if "*" in allowed:
        return tables
    allowed_l = {a.lower() for a in allowed}
    return [t for t in tables if t.lower() in allowed_l]


def list_tables(allowed: list[str], search: str = "") -> list[str]:
    names = _visible(allowed)
    if search:
        s = search.lower()
        names = [n for n in names if s in n.lower()]
    return names


@lru_cache(maxsize=512)
def _describe(table: str) -> dict:
    insp = inspect(engine)
    cols = [{"name": c["name"], "type": str(c["type"]),
             **({"comment": c["comment"]} if c.get("comment") else {})}
            for c in insp.get_columns(table)]
    try:
        fks = [{"columns": f["constrained_columns"], "ref_table": f["referred_table"],
                "ref_columns": f["referred_columns"]} for f in insp.get_foreign_keys(table)]
    except Exception:
        fks = []
    try:
        comment = (insp.get_table_comment(table) or {}).get("text") or ""
    except Exception:
        comment = ""
    return {"table": table, "comment": comment, "columns": cols, "foreign_keys": fks}


def describe_tables(names: list[str], allowed: list[str]) -> list[dict]:
    visible = {t.lower(): t for t in _visible(allowed)}
    out = []
    for n in names[:15]:
        real = visible.get(n.lower())
        out.append(_describe(real) if real else {"table": n, "error": "not found or not allowed"})
    return out


# ------------------------------------------------------------------ validation
def validate_select(sql: str, allowed: list[str]) -> str:
    sql = sql.strip().rstrip(";").strip()
    try:
        statements = sqlglot.parse(sql, read=DIALECT)
    except sqlglot.errors.ParseError as e:
        raise SQLRejected(f"SQL could not be parsed: {e}") from e
    statements = [s for s in statements if s is not None]
    if len(statements) != 1:
        raise SQLRejected("Exactly one SQL statement is allowed.")
    tree = statements[0]
    if not isinstance(tree, (exp.Select, exp.Union, exp.Intersect, exp.Except)):
        raise SQLRejected("Only SELECT queries are allowed (read-only bot).")
    for node in tree.walk():
        if isinstance(node, BLOCKED_NODES):
            raise SQLRejected(f"{type(node).__name__} is not allowed.")
        if isinstance(node, exp.Func):
            fname = (node.sql_name() if not isinstance(node, exp.Anonymous) else node.name).lower()
            if fname in BLOCKED_FUNCTIONS:
                raise SQLRejected(f"Function {fname} is not allowed.")
    low = sql.lower()
    if "outfile" in low or "dumpfile" in low:
        raise SQLRejected("INTO OUTFILE is not allowed.")

    if "*" not in allowed:
        cte_names = {c.alias_or_name.lower() for c in tree.find_all(exp.CTE)}
        allowed_l = {a.lower() for a in allowed}
        for t in tree.find_all(exp.Table):
            name = t.name.lower()
            if name and name not in cte_names and name not in allowed_l:
                raise SQLRejected(f"Your role is not allowed to read table '{t.name}'.")
    return sql


# ------------------------------------------------------------------ execution
def _jsonable(v):
    if isinstance(v, decimal.Decimal):
        return float(v)
    if isinstance(v, (dt.datetime, dt.date, dt.time)):
        return v.isoformat()
    if isinstance(v, (bytes, bytearray)):
        return v.decode("utf-8", errors="replace")
    return v


def run_select(sql: str, allowed: list[str], max_rows: int | None = None) -> dict:
    sql = validate_select(sql, allowed)
    max_rows = max_rows or config.MAX_ROWS
    start = time.time()
    with engine.connect() as conn:
        if DIALECT == "mysql":
            conn.execute(text("SET SESSION TRANSACTION READ ONLY"))
            conn.execute(text(f"SET SESSION MAX_EXECUTION_TIME={config.QUERY_TIMEOUT_SECONDS * 1000}"))
        result = conn.execute(text(sql))
        columns = list(result.keys())
        raw = result.fetchmany(max_rows + 1)
        conn.rollback()
    truncated = len(raw) > max_rows
    rows = [[_jsonable(v) for v in r] for r in raw[:max_rows]]
    return {"columns": columns, "rows": rows, "row_count": len(rows),
            "truncated": truncated, "seconds": round(time.time() - start, 2), "sql": sql}

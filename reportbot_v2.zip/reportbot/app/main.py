"""FastAPI app: web chat (URL chatbot), REST API for n8n, Telegram webhook, file downloads.

Run:  uvicorn app.main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import hmac
import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import BackgroundTasks, Depends, FastAPI, Header, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel

from . import agent, config, datadb, scheduler, store, telegram

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("reportbot")
STATIC = Path(__file__).parent / "static"


@asynccontextmanager
async def lifespan(_app: FastAPI):
    store.init_db()
    scheduler.start()
    if config.TELEGRAM_BOT_TOKEN and config.TELEGRAM_MODE == "direct" \
            and config.PUBLIC_BASE_URL.startswith("https://"):
        try:
            log.info("telegram webhook: %s", telegram.set_webhook())
            telegram.set_commands()
        except Exception as e:
            log.error("could not register telegram webhook: %s", e)
    yield


app = FastAPI(title="ReportBot", lifespan=lifespan)


# ------------------------------------------------------------------ auth
def current_user(authorization: str = Header(default=""), x_api_key: str = Header(default=""),
                 x_telegram_id: str = Header(default="")) -> dict:
    """Web users: 'Authorization: Bearer <session token from /api/login>'
    (or a personal web_token when WEB_REQUIRE_PASSWORD=false).
    n8n / other systems: 'X-API-Key: <SERVICE_API_KEY>' + 'X-Telegram-Id: <acting user>'."""
    if authorization.lower().startswith("bearer "):
        tok = authorization[7:].strip()
        u = store.get_user_by_session(tok)
        if not u and not config.WEB_REQUIRE_PASSWORD:
            u = store.get_user_by_token(tok)
        if u:
            u["_session"] = tok
            return u
    if x_api_key and config.SERVICE_API_KEY and hmac.compare_digest(x_api_key, config.SERVICE_API_KEY):
        u = store.get_user_by_telegram(x_telegram_id) if x_telegram_id else None
        if u:
            return u
        raise HTTPException(403, "Unknown X-Telegram-Id user")
    raise HTTPException(401, "Not logged in")


def _reply_json(r: agent.AgentReply) -> dict:
    return {"text": r.text, "report_ids": r.report_ids, "tables": r.tables, "preview": r.preview,
            "files": [{k: f[k] for k in ("format", "filename", "url")} for f in r.files]}


# ------------------------------------------------------------------ login
_fails: dict[str, list[float]] = {}  # key -> timestamps of failed attempts


def _locked(key: str) -> bool:
    now = time.time()
    window = config.LOGIN_LOCK_MINUTES * 60
    _fails[key] = [t for t in _fails.get(key, []) if now - t < window]
    return len(_fails[key]) >= config.LOGIN_MAX_FAILS


class LoginIn(BaseModel):
    username: str
    password: str


@app.get("/api/auth-mode")
def auth_mode():
    return {"password_required": config.WEB_REQUIRE_PASSWORD}


@app.post("/api/login")
def login(body: LoginIn, request: Request):
    ip = request.headers.get("cf-connecting-ip") or (request.client.host if request.client else "?")
    keys = [f"u:{body.username.strip().lower()}", f"ip:{ip}"]
    if any(_locked(k) for k in keys):
        raise HTTPException(429, f"Too many wrong attempts. Try again in {config.LOGIN_LOCK_MINUTES} minutes.")
    u = store.authenticate(body.username, body.password)
    if not u:
        for k in keys:
            _fails.setdefault(k, []).append(time.time())
        log.warning("failed login for %s from %s", body.username, ip)
        raise HTTPException(401, "Wrong username or password")
    for k in keys:
        _fails.pop(k, None)
    log.info("login ok: %s from %s", u["username"], ip)
    return {"token": store.create_session(u["id"], config.SESSION_HOURS), "name": u["name"]}


@app.post("/api/logout")
def logout(user: dict = Depends(current_user)):
    if user.get("_session"):
        store.end_session(user["_session"])
    return {"ok": True}


class PasswordIn(BaseModel):
    old_password: str
    new_password: str


@app.post("/api/change-password")
def change_password(body: PasswordIn, user: dict = Depends(current_user)):
    try:
        store.change_password(user["id"], body.old_password, body.new_password)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "note": "Password changed. Please log in again."}


# ------------------------------------------------------------------ web chat
@app.get("/", response_class=HTMLResponse)
def index():
    return (STATIC / "index.html").read_text(encoding="utf-8")


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/api/me")
def me(user: dict = Depends(current_user)):
    role = store.get_role(user["role"])
    return {"name": user["name"], "role": user["role"],
            "can_teach": bool(role.get("can_teach")), "can_schedule": bool(role.get("can_schedule")),
            "skills": [{"name": s["name"], "title": s["title"]} for s in store.list_skills(user)]}


class ChatIn(BaseModel):
    message: str


@app.post("/api/chat")
async def chat(body: ChatIn, user: dict = Depends(current_user)):
    reply = await run_in_threadpool(agent.handle_message, user, body.message, "web",
                                    f"web:{user['id']}", user.get("telegram_id") or "")
    return _reply_json(reply)


@app.post("/api/chat/reset")
def chat_reset(user: dict = Depends(current_user)):
    store.clear_chat(f"web:{user['id']}")
    return {"ok": True}


# ------------------------------------------------------------------ skills (teach node API)
class SkillIn(BaseModel):
    name: str
    title: str
    description: str = ""
    rules: str = ""
    output_format: str = ""
    default_formats: list[str] | str = "table"
    sql_template: str = ""
    example_output: str = ""
    allowed_roles: list[str] = []


@app.get("/api/skills")
def skills_list(user: dict = Depends(current_user)):
    return store.list_skills(user)


@app.get("/api/skills/{name}")
def skill_get(name: str, user: dict = Depends(current_user)):
    s = store.get_skill(name)
    if not s or not store.skill_allowed(s, user):
        raise HTTPException(404, "not found")
    return s


@app.post("/api/skills")
def skill_save(body: SkillIn, user: dict = Depends(current_user)):
    """Direct teaching (used by the n8n 'Teach Report' form). If no SQL is given, the agent
    will work it out the first time the report runs and you can save it back via chat."""
    if not store.get_role(user["role"]).get("can_teach"):
        raise HTTPException(403, "Your role cannot teach reports")
    try:
        s = store.save_skill(body.model_dump(), changed_by=user["name"])
    except ValueError as e:
        raise HTTPException(400, str(e))
    if config.TELEGRAM_BOT_TOKEN:
        try:
            telegram.set_commands()
        except Exception:
            pass
    return {"saved": True, "command": "/" + s["name"], "version": s["version"]}


@app.delete("/api/skills/{name}")
def skill_delete(name: str, user: dict = Depends(current_user)):
    if not store.get_role(user["role"]).get("can_teach"):
        raise HTTPException(403, "Your role cannot change reports")
    return {"deleted": store.delete_skill(name)}


class RunIn(BaseModel):
    prompt: str = ""
    formats: list[str] = []
    deliver_to_chat_id: str = ""   # send the result to this Telegram chat as well


@app.post("/api/skills/{name}/run")
async def skill_run(name: str, body: RunIn, user: dict = Depends(current_user)):
    text = f"/{name} {body.prompt}".strip()
    if body.formats:
        text += f"\n(Output formats: {','.join(body.formats)}. Do not ask questions.)"
    reply = await run_in_threadpool(agent.handle_message, user, text, "n8n",
                                    f"api:{user['id']}:{name}", body.deliver_to_chat_id, False)
    if body.deliver_to_chat_id and config.TELEGRAM_BOT_TOKEN:
        await run_in_threadpool(telegram.send_reply, body.deliver_to_chat_id, reply)
    return _reply_json(reply)


# ------------------------------------------------------------------ history & schedules
@app.get("/api/history")
def history(q: str = "", skill: str = "", limit: int = 20, user: dict = Depends(current_user)):
    rows = store.search_reports(user, q, skill, min(limit, 100))
    for r in rows:
        r["files"] = [{k: f[k] for k in ("format", "filename", "url")} for f in r["files"] or []]
    return rows


@app.get("/api/schedules")
def schedules_list(user: dict = Depends(current_user)):
    return [{**s, "next_run": scheduler.next_run(s["id"])} for s in store.list_schedules(user)]


@app.post("/api/schedules/{schedule_id}/run")
async def schedule_run_now(schedule_id: int, user: dict = Depends(current_user)):
    if schedule_id not in {s["id"] for s in store.list_schedules(user)}:
        raise HTTPException(404, "not found")
    return await run_in_threadpool(scheduler.run_schedule, schedule_id)


# ------------------------------------------------------------------ users (admin)
class UserIn(BaseModel):
    name: str
    role: str = "viewer"
    telegram_id: str | None = None
    username: str | None = None
    password: str | None = None


@app.get("/api/users")
def users_list(user: dict = Depends(current_user)):
    if not store.get_role(user["role"]).get("is_admin"):
        raise HTTPException(403)
    return [{k: v for k, v in u.items() if k != "password_hash"} for u in store.list_users()]


@app.post("/api/users")
def users_add(body: UserIn, user: dict = Depends(current_user)):
    if not store.get_role(user["role"]).get("is_admin"):
        raise HTTPException(403)
    nu = store.add_user(body.name, body.role, body.telegram_id)
    if body.username and body.password:
        try:
            store.set_login(nu["id"], body.username, body.password)
        except ValueError as e:
            raise HTTPException(400, str(e))
    nu = store.get_user(nu["id"])
    nu.pop("password_hash", None)
    return {**nu, "web_link": f"{config.PUBLIC_BASE_URL}/"}


@app.post("/api/admin/refresh-schema")
def refresh_schema(user: dict = Depends(current_user)):
    if not store.get_role(user["role"]).get("is_admin"):
        raise HTTPException(403)
    datadb.refresh_schema_cache()
    return {"ok": True}


# ------------------------------------------------------------------ n8n
class N8nChatIn(BaseModel):
    telegram_id: str
    chat_id: str
    text: str
    deliver: bool = False  # True = this server sends the reply to Telegram itself


@app.post("/api/n8n/chat")
async def n8n_chat(body: N8nChatIn, x_api_key: str = Header(default="")):
    if not (config.SERVICE_API_KEY and hmac.compare_digest(x_api_key, config.SERVICE_API_KEY)):
        raise HTTPException(401, "bad api key")
    user = store.get_user_by_telegram(body.telegram_id)
    if not user:
        return {"registered": False, "text": f"🙏 Not registered. Send this id to your admin: "
                                             f"{body.telegram_id}", "files": [], "tables": []}
    if body.text.startswith("/"):
        cmd = body.text[1:].split()[0].split("@")[0].lower()
        if cmd in {"start", "help", "myid", "new", "skills", "history", "schedules", "adduser"}:
            await run_in_threadpool(telegram.process_update, {"message": {
                "chat": {"id": body.chat_id, "type": "private"},
                "from": {"id": body.telegram_id}, "text": body.text}})
            return {"registered": True, "handled": True, "text": "", "files": [], "tables": []}
    reply = await run_in_threadpool(agent.handle_message, user, body.text, "telegram",
                                    f"tg:{body.chat_id}", body.chat_id)
    if body.deliver:
        await run_in_threadpool(telegram.send_reply, body.chat_id, reply)
    return {"registered": True, **_reply_json(reply)}


# ------------------------------------------------------------------ telegram (direct mode)
@app.post("/telegram/webhook")
async def telegram_webhook(request: Request, background: BackgroundTasks,
                           x_telegram_bot_api_secret_token: str = Header(default="")):
    if config.TELEGRAM_WEBHOOK_SECRET and not hmac.compare_digest(
            x_telegram_bot_api_secret_token, config.TELEGRAM_WEBHOOK_SECRET):
        raise HTTPException(401)
    update = await request.json()
    background.add_task(telegram.process_update, update)  # reply fast, work in background
    return {"ok": True}


# ------------------------------------------------------------------ files
@app.get("/files/{folder}/{filename}")
def get_file(folder: str, filename: str):
    if not folder.isalnum() or "/" in filename or ".." in filename:
        raise HTTPException(400)
    p = config.OUTPUT_DIR / folder / filename
    if not p.is_file():
        raise HTTPException(404)
    inline = p.suffix in (".html", ".png", ".pdf")
    return FileResponse(p, filename=filename,
                        content_disposition_type="inline" if inline else "attachment")

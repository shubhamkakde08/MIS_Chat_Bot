# ReportBot — Teachable AI report agent for Telegram + Web (MySQL + Claude)

Chat in **English, हिंदी, ગુજરાતી or मराठी** (native script or Hinglish), get reports from your MySQL as
**chat table, Excel, PDF, chart or HTML** — and **teach** the bot your company's report formats once,
then run them forever as `/commands`.

```
 Telegram ─┐                          ┌─► MySQL (your ERP, read-only)
 Web chat ─┼─► FastAPI ─► Claude agent ┤
 n8n ──────┘      │                    └─► Report skills ─► Excel · PDF · Chart · HTML · Table
                  └─► Scheduler (cron) ─► Telegram groups
             Bot DB: skills (versioned) · report history · users/roles · schedules · chat memory
```

## What it does

| Feature | How |
|---|---|
| **Teach a report** ("the node") | `/teach` in chat — the bot interviews you like an analyst (purpose, rules, columns, totals, formats, example), explores your tables, writes + tests SQL, shows a preview, and saves it as `/your_report`. Or use the **Teach Report form** node in n8n. Send an example Excel/CSV/PDF and it copies the layout. |
| **Run a report** | `/daily_sales`, `/daily_sales Surat branch last week pdf`, or just ask: *"kal ka dispatch excel me do"* |
| **Rules = regulations** | Each skill stores numbered business rules (e.g. *exclude cancelled, amount without GST, use invoice date*). The agent must follow them every run. Every change is versioned. |
| **History** | Every report is saved (SQL, summary, files, first 50 rows). *"report #12 ko pdf me bhejo"*, *"compare with last week's report"*, `/history`. |
| **Formats** | Table in chat · Excel (styled, ₹ lakh/crore, SUM totals, filters, chart sheet) · PDF (Hindi/Gujarati/Marathi fonts) · Chart PNG · HTML page |
| **Scheduled reports** | *"roj subah 9 baje /daily_sales sales group me bhejo"* → runs automatically, sends files to Telegram |
| **Role-based access** | `admin` / `manager` / `viewer` (+ your own). Per role: allowed tables, can teach, can schedule, free questions. Per skill: allowed roles. |
| **Safe** | Read-only MySQL user + SQL parser (SELECT only, no OUTFILE/SLEEP, table whitelist) + READ ONLY session + timeout |

---

## Setup (about 20 minutes)

### 1. Telegram bot
Open **@BotFather** → `/newbot` → copy the token. (For groups: `/setprivacy` → Disable is *not* needed; the bot answers commands, @mentions and replies.)

### 2. MySQL users
```sql
-- read-only user for your ERP data
CREATE USER 'reportbot_ro'@'%' IDENTIFIED BY 'strong-password';
GRANT SELECT ON your_erp_db.* TO 'reportbot_ro'@'%';

-- the bot's own storage (skills, history, users, schedules)
CREATE DATABASE reportbot CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'reportbot_rw'@'%' IDENTIFIED BY 'another-password';
GRANT ALL ON reportbot.* TO 'reportbot_rw'@'%';
```
Tip: add `COMMENT`s to important tables/columns (`ALTER TABLE invoices MODIFY amount DECIMAL(14,2) COMMENT 'taxable value excl GST'`) — the agent reads them and gets smarter.

### 3. Configure & start
```bash
cp .env.example .env        # fill in keys, DB URLs, Telegram token, PUBLIC_BASE_URL (https)
docker compose up -d --build
docker compose exec reportbot python -m tools.manage init          # prints the admin web link
docker compose exec reportbot python -m tools.manage seed-skills   # optional: 2 example skills
```
The server needs a public **HTTPS** URL for Telegram (use Nginx/Caddy, or Cloudflare Tunnel for testing).
On start it registers the Telegram webhook automatically (`TELEGRAM_MODE=direct`).

Without Docker: `pip install -r requirements.txt` (+ Pango & Noto fonts for PDF), then
`uvicorn app.main:app --host 0.0.0.0 --port 8000`.

### 4. Add people
In Telegram each person sends `/myid` (or `/start`) and gets their id. Admin then:
```
/adduser 987654321 manager Ramesh Patel
```
They also get a personal web link `https://your-url/?token=...` for the URL chatbot.

---

## Using it

**Teach** (managers/admins):
```
/teach
→ "Daily dispatch report chahiye — branch wise, MT me, cancelled challan nahi, PDF + Excel"
→ bot asks a few questions, shows a preview, you say "ok save" → /daily_dispatch is live
/teach daily_dispatch  → change an existing report (new version, old kept)
```
**Run**: `/daily_dispatch`, `/daily_dispatch Pune 1-15 Oct excel`, or *"ગઈકાલનું dispatch report આપો"*
**Ask**: *"is mahine top 10 customers kaun hai?"*, *"या महिन्याची एकूण विक्री किती?"*
**Schedule**: *"har somvar 10 baje /pending_orders mujhe bhejo"*, `/schedules`
**History**: `/history`, *"#12 wala report chart ke saath dobara"*

Roles (edit `rb_roles` table): `allowed_tables` = `["*"]` or a list like `["invoices","branches"]`.
Viewers (`free_query = 0`) can only run taught `/reports` — great for branch staff.

---

## n8n
Import `n8n/reportbot_workflow.json`. It contains:
1. **Telegram Trigger → Ask ReportBot → reply + files** (set `TELEGRAM_MODE=n8n` in `.env` so only n8n receives Telegram updates)
2. **Teach Report Form** node → saves a skill via `POST /api/skills` → shows the new `/command`
3. **Schedule example** → `POST /api/skills/daily_sales/run` delivered to a group

Set env vars on n8n: `REPORTBOT_URL`, `REPORTBOT_API_KEY` (= `SERVICE_API_KEY`), and attach your Telegram credential.
`docker compose --profile n8n up -d` starts n8n pre-wired.

## API (for n8n / other apps)
Auth: `Authorization: Bearer <user web token>` **or** `X-API-Key: <SERVICE_API_KEY>` + `X-Telegram-Id: <acting user>`.

| Method | Path | |
|---|---|---|
| POST | `/api/chat` | `{"message": "..."}` → text, preview tables, file URLs |
| GET/POST | `/api/skills` | list / create-update a skill |
| POST | `/api/skills/{name}/run` | `{"prompt","formats","deliver_to_chat_id"}` |
| GET | `/api/history?q=&skill=` | past reports |
| GET | `/api/schedules`, POST `/api/schedules/{id}/run` | schedules |
| POST | `/api/users` | add user (admin) |
| POST | `/api/n8n/chat` | Telegram-style message from n8n |

## Files
```
app/agent.py       Claude agent: tools, system prompt (languages, Indian FY, teaching interview)
app/datadb.py      read-only MySQL access + SQL guard + schema discovery
app/store.py       bot tables: roles, users, skills (+versions), reports, schedules, messages
app/renderers.py   table / Excel / PDF / chart / HTML
app/telegram.py    Telegram webhook, commands, file delivery, example-file reading
app/scheduler.py   cron schedules → Telegram
app/main.py        FastAPI routes;  app/static/index.html = web chat
n8n/               importable workflow   ·   sql/ DDL   ·   examples/skills/   ·   tests/
```
Run tests (no keys needed — fake Claude + sample SQLite ERP): `python -m pytest -q tests/`

## Notes
- Model: `CLAUDE_MODEL` (default `claude-sonnet-5-5`; use `claude-haiku-5-5` for cheaper quick questions). The long system prompt is prompt-cached.
- Report file links are unguessable URLs; put the server behind your VPN/firewall if files are sensitive, and clean `/data/output` periodically.
- Big ERPs (hundreds of tables): the agent searches tables by name and only describes what it needs, so it scales. Table/column comments help a lot.

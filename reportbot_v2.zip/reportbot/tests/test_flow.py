"""End-to-end test with a sample SQLite "ERP" and a scripted fake Claude.

Run:  python -m pytest -q tests/   (no API key or MySQL needed)
"""
import os
import random
import sqlite3
import sys
import tempfile
from datetime import date, timedelta
from pathlib import Path
from types import SimpleNamespace

TMP = Path(tempfile.mkdtemp(prefix="rbtest_"))
os.environ.update(
    DATA_DB_URL=f"sqlite:///{TMP/'erp.db'}", BOT_DB_URL=f"sqlite:///{TMP/'bot.db'}",
    OUTPUT_DIR=str(TMP / "out"), SERVICE_API_KEY="svc", BOOTSTRAP_ADMIN_WEB_TOKEN="admintok",
    BOOTSTRAP_ADMIN_TELEGRAM_ID="111", TELEGRAM_BOT_TOKEN="", PUBLIC_BASE_URL="http://test",
    WEB_REQUIRE_PASSWORD="true",
)
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def make_sample_erp(path: Path):
    con = sqlite3.connect(path)
    con.executescript("""
    CREATE TABLE branches(id INTEGER PRIMARY KEY, name TEXT);
    CREATE TABLE customers(id INTEGER PRIMARY KEY, name TEXT, city TEXT);
    CREATE TABLE invoices(id INTEGER PRIMARY KEY, invoice_no TEXT, invoice_date DATE,
        branch_id INTEGER REFERENCES branches(id), customer_id INTEGER REFERENCES customers(id),
        qty_mt REAL, amount REAL, status TEXT);
    CREATE TABLE salaries(id INTEGER PRIMARY KEY, emp TEXT, salary REAL);
    """)
    con.executemany("INSERT INTO branches VALUES(?,?)",
                    [(1, "Surat"), (2, "Ahmedabad"), (3, "Pune"), (4, "Indore")])
    con.executemany("INSERT INTO customers VALUES(?,?,?)",
                    [(i, f"Customer {i}", random.choice(["Surat", "Pune", "Delhi"])) for i in range(1, 21)])
    rnd = random.Random(7)
    rows, d0 = [], date.today() - timedelta(days=40)
    for i in range(1, 600):
        d = d0 + timedelta(days=rnd.randint(0, 40))
        rows.append((i, f"INV{i:05d}", d.isoformat(), rnd.randint(1, 4), rnd.randint(1, 20),
                     round(rnd.uniform(1, 25), 2), round(rnd.uniform(20000, 900000), 2),
                     "C" if rnd.random() < 0.08 else "A"))
    con.executemany("INSERT INTO invoices VALUES(?,?,?,?,?,?,?,?)", rows)
    con.execute("INSERT INTO salaries VALUES(1,'x',1)")
    con.commit()


make_sample_erp(TMP / "erp.db")

from app import agent, datadb, renderers, store  # noqa: E402

store.init_db()

SQL = """SELECT b.name AS Branch, COUNT(*) AS Invoices, ROUND(SUM(i.qty_mt),2) AS "Qty (MT)",
 ROUND(SUM(i.amount),2) AS "Amount" FROM invoices i JOIN branches b ON b.id=i.branch_id
 WHERE i.status <> 'C' GROUP BY b.name ORDER BY "Amount" DESC"""


# ------------------------------------------------------------- fake Claude
def tool_use(name, inp, i):
    return SimpleNamespace(type="tool_use", id=f"tu{i}", name=name, input=inp)


def text(t):
    return SimpleNamespace(type="text", text=t)


class FakeClaude:
    """Replays a script of responses; records what the agent sent back."""
    def __init__(self, script):
        self.script, self.calls = list(script), []
        self.messages = self

    def create(self, **kw):
        self.calls.append({**kw, "messages": list(kw["messages"])})
        content, stop = self.script.pop(0)
        return SimpleNamespace(content=content, stop_reason=stop)


def admin():
    return store.get_user_by_token("admintok")


# ------------------------------------------------------------- tests
def test_sql_guard():
    for bad in ["DELETE FROM invoices", "SELECT 1; DROP TABLE invoices",
                "UPDATE invoices SET amount=0", "SELECT * FROM invoices INTO OUTFILE '/tmp/x'"]:
        try:
            datadb.validate_select(bad, ["*"])
            raise AssertionError(f"not rejected: {bad}")
        except datadb.SQLRejected:
            pass
    datadb.validate_select("WITH x AS (SELECT * FROM invoices) SELECT * FROM x", ["invoices"])
    try:
        datadb.validate_select("SELECT * FROM salaries", ["invoices", "branches"])
        raise AssertionError("role table restriction failed")
    except datadb.SQLRejected:
        pass


def test_indian_numbers():
    assert renderers.indian_group(12345678.5) == "1,23,45,678.50"
    assert renderers.indian_group(999, 0) == "999"
    assert renderers.indian_group(-100000, 0) == "-1,00,000"


def test_teach_then_run_with_all_formats():
    # 1) Teaching: agent explores, tests SQL, saves the skill
    agent.client = FakeClaude([
        ([tool_use("list_tables", {"search": ""}, 1)], "tool_use"),
        ([tool_use("describe_tables", {"tables": ["invoices", "branches"]}, 2)], "tool_use"),
        ([tool_use("run_sql", {"sql": SQL}, 3)], "tool_use"),
        ([tool_use("save_report_skill", {
            "name": "branch_sales", "title": "Branch-wise Sales",
            "rules": "1. Exclude cancelled (status='C')\n2. Amount without GST",
            "output_format": "Branch | Invoices | Qty (MT) | Amount, sort Amount desc, total row, bar chart",
            "default_formats": ["table", "excel", "pdf", "chart", "html"], "sql_template": SQL}, 4)],
         "tool_use"),
        ([text("✅ Saved. Run it any time with /branch_sales")], "end_turn"),
    ])
    r = agent.handle_message(admin(), "/teach branch wise sales", "web", "web:t1")
    assert "branch_sales" in r.text
    tools_seen = [c for c in agent.client.calls[3]["messages"][-1]["content"]]
    assert '"row_count": 4' in tools_seen[0]["content"]
    assert store.get_skill("branch_sales")["version"] == 1

    # 2) Running the skill in Hindi -> all 5 formats
    agent.client = FakeClaude([
        ([tool_use("run_sql", {"sql": SQL}, 5)], "tool_use"),
        ([tool_use("create_report", {
            "result_id": "r1", "title": "शाखा अनुसार बिक्री", "subtitle": "पिछले 40 दिन",
            "summary": "कुल बिक्री में सूरत सबसे आगे है।\nरद्द इनवॉइस शामिल नहीं हैं।",
            "formats": ["table", "excel", "pdf", "chart", "html"],
            "column_formats": {"Amount": "currency", "Qty (MT)": "number"},
            "total_columns": ["Invoices", "Qty (MT)", "Amount"],
            "chart": {"type": "bar", "x": "Branch", "y": ["Amount"]}}, 6)], "tool_use"),
        ([text("रिपोर्ट तैयार है।")], "end_turn"),
    ])
    r = agent.handle_message(admin(), "/branch_sales hindi me", "telegram", "tg:111")
    # the skill definition was injected into the first user message
    first_user = agent.client.calls[0]["messages"][-1]["content"]
    assert "<skill_definition>" in first_user and "Exclude cancelled" in first_user
    fmts = sorted(f["format"] for f in r.files)
    assert fmts == ["chart", "excel", "html", "pdf"], fmts
    assert r.tables and "TOTAL" in r.tables[0]
    for f in r.files:
        assert Path(f["path"]).stat().st_size > 1000
    # 3) History
    hist = store.search_reports(admin())
    assert hist and hist[0]["skill_name"] == "branch_sales"
    print("\nFILES:", *[f["path"] for f in r.files], sep="\n  ")
    print(r.tables[0])


def test_viewer_cannot_free_query_or_teach():
    v = store.add_user("Viewer", "viewer", telegram_id="222")
    agent.client = FakeClaude([
        ([tool_use("run_sql", {"sql": "SELECT * FROM invoices"}, 1),
          tool_use("save_report_skill", {"name": "x_y", "title": "t", "rules": "r",
                                         "output_format": "f"}, 2)], "tool_use"),
        ([text("Sorry")], "end_turn"),
    ])
    agent.handle_message(v, "show all invoices", "web", "web:v")
    results = agent.client.calls[1]["messages"][-1]["content"]
    assert "only run taught reports" in results[0]["content"]
    assert "not allowed to teach" in results[1]["content"]


def test_schedule_creation():
    from app import scheduler
    agent.client = FakeClaude([
        ([tool_use("create_schedule", {"skill_name": "branch_sales", "cron": "0 9 * * 1-6"}, 1)],
         "tool_use"),
        ([text("Har subah 9 baje bhej dunga.")], "end_turn"),
    ])
    agent.handle_message(admin(), "roj subah 9 baje /branch_sales bhejo", "telegram", "tg:111",
                         default_chat_id="111")
    s = store.list_schedules()
    assert s and s[0]["cron"] == "0 9 * * 1-6"
    assert scheduler.next_run(s[0]["id"])


def _login(c, username, password):
    return c.post("/api/login", json={"username": username, "password": password})


def test_web_login_and_api():
    from fastapi.testclient import TestClient
    from app.main import app
    store.set_login(1, "admin", "AdminPass123")
    with TestClient(app) as c:
        assert c.get("/api/auth-mode").json()["password_required"] is True
        # old personal token links no longer work in password mode
        assert c.get("/api/me", headers={"Authorization": "Bearer admintok"}).status_code == 401
        assert _login(c, "admin", "wrong-pass").status_code == 401
        r = _login(c, "ADMIN", "AdminPass123")          # usernames are case-insensitive
        assert r.status_code == 200, r.text
        H = {"Authorization": "Bearer " + r.json()["token"]}
        me = c.get("/api/me", headers=H).json()
        assert me["role"] == "admin" and any(s["name"] == "branch_sales" for s in me["skills"])
        # password hash is never returned
        assert all("password_hash" not in u for u in c.get("/api/users", headers=H).json())
        # n8n teach-form path still works with API key
        r = c.post("/api/skills", headers={"X-API-Key": "svc", "X-Telegram-Id": "111"},
                   json={"name": "Daily Dispatch", "title": "Daily Dispatch", "rules": "1. x",
                         "output_format": "y", "default_formats": ["excel"]})
        assert r.json()["command"] == "/daily_dispatch", r.text
        h = c.get("/api/history", headers=H).json()
        assert c.get(h[0]["files"][0]["url"].replace("http://test", "")).status_code == 200
        # change password -> old session ends, new password works
        assert c.post("/api/change-password", headers=H,
                      json={"old_password": "AdminPass123", "new_password": "NewPass4567"}).status_code == 200
        assert c.get("/api/me", headers=H).status_code == 401
        r = _login(c, "admin", "NewPass4567")
        H = {"Authorization": "Bearer " + r.json()["token"]}
        assert c.post("/api/logout", headers=H).status_code == 200
        assert c.get("/api/me", headers=H).status_code == 401
        assert "Sign in" in c.get("/").text


def test_lockout_and_disable():
    from fastapi.testclient import TestClient
    from app.main import app, _fails
    _fails.clear()
    u = store.add_user("Lock Test", "viewer")
    store.set_login(u["id"], "locktest", "RightPass99")
    with TestClient(app) as c:
        for _ in range(5):
            assert _login(c, "locktest", "nope").status_code == 401
        assert _login(c, "locktest", "RightPass99").status_code == 429   # locked even with right pw
        _fails.clear()
        tok = _login(c, "locktest", "RightPass99").json()["token"]
        store.set_active(u["id"], False)                                  # disable -> session dead
        assert c.get("/api/me", headers={"Authorization": "Bearer " + tok}).status_code == 401
        assert _login(c, "locktest", "RightPass99").status_code == 401
    _fails.clear()


def test_password_rules_and_upgrade():
    import pytest
    with pytest.raises(ValueError):
        store.set_login(1, "ab", "longenough1")          # username too short
    with pytest.raises(ValueError):
        store.set_login(1, "admin", "short")             # password too short
    h = store.hash_password("Secret123")
    assert h.startswith("pbkdf2_sha256$") and "Secret123" not in h
    assert store.check_password("Secret123", h) and not store.check_password("secret123", h)
    # an install from before this update (no username/password columns) is upgraded in place
    import sqlalchemy as sa
    e = sa.create_engine(f"sqlite:///{TMP/'old.db'}")
    with e.begin() as c:
        c.execute(sa.text("CREATE TABLE rb_users (id INTEGER PRIMARY KEY, name TEXT, role TEXT, "
                          "telegram_id TEXT, web_token TEXT, active BOOLEAN, created_at DATETIME)"))
    old_engine = store.engine
    store.engine = e
    try:
        store._upgrade_existing_tables()
        cols = {c["name"] for c in sa.inspect(e).get_columns("rb_users")}
        assert {"username", "password_hash"} <= cols
        store._upgrade_existing_tables()                 # running twice is harmless
    finally:
        store.engine = old_engine
